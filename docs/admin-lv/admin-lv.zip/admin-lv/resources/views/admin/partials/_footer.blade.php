<footer class="main-footer">
    <!-- To the right -->
    <div class="float-end d-none d-sm-inline">
        Powered by <strong><a class="text-decoration-none" href="#">WikiGods</a></strong>
    </div>
    <!-- Default to the left -->
    Copyright &copy; {{ date('Y') }} {{ config('app.name') }} v1.0
</footer>
