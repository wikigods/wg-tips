<ol class="breadcrumb rounded">
    <li class="breadcrumb-item"><a href="#" class="text-decoration-none">Home</a></li>
    <li class="breadcrumb-item active">Starter Page</li>
</ol>
