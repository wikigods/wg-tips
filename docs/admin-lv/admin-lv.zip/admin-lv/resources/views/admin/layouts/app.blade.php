<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>@yield('title', config('app.name')) | {{ config('app.name') }}</title>

        <!-- Google Font: Source Sans Pro -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
        <!-- Theme style -->
        @vite(['resources/sass/admin.scss'])
        @stack('styles')
    </head>
    <body class="hold-transition sidebar-mini layout-fixed">
        <div id="app" class="wrapper">

            @include('admin.partials._navbar')

            @include('admin.partials._sidebar')

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <div class="content-header">
                    <div class="container-fluid">
                        @yield('breadcrumbs')
                    </div>
                </div>
                <!-- /.content-header -->

                <!-- Main content -->
                <div class="content">
                    <div class="container-fluid">
                        @include('admin.partials._notifications')
                        @yield('content')
                    </div><!-- /.container-fluid -->
                </div>
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->

            @include('admin.partials._footer')
        </div>
        <!-- ./wrapper -->

        <!-- AdminLTE App -->
        @vite(['resources/js/admin.js'])
        @include('admin.partials._change-log')
        @stack('scripts')
    </body>
</html>
