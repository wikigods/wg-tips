@extends('admin.layouts.app')

@section('content')

<admin-component></admin-component>
@endsection
